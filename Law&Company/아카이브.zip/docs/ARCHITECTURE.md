# Slack Q&A Chatbot 아키텍처 문서

## 시스템 개요

Slack Q&A Chatbot은 마이크로서비스 아키텍처로 설계된 지능형 자동 응답 시스템입니다. 슬랙 채널의 문의와 답변을 자동으로 수집하고, AI를 활용하여 Q&A 데이터를 생성하며, 유사한 질문에 대해 자동으로 답변을 제공합니다.

## 아키텍처 다이어그램

### High-Level 아키텍처

```
┌─────────────────────────────────────────────────────────────────┐
│                         Slack Workspace                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   Channels   │  │   Mentions   │  │   Commands   │          │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘          │
└─────────┼──────────────────┼──────────────────┼──────────────────┘
          │                  │                  │
          │ Events API       │ Events API       │ Slash Commands
          ▼                  ▼                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Application Layer                           │
│                                                                   │
│  ┌──────────────────────┐         ┌──────────────────────┐      │
│  │  Slack Collector     │         │      Chatbot         │      │
│  │  (Node.js/TS)        │         │  (Node.js/TS)        │      │
│  │  Port: 3000          │         │  Port: 3001          │      │
│  │                      │         │                      │      │
│  │ • Event Handler      │         │ • Command Handler    │      │
│  │ • Thread Detector    │         │ • Query Processor    │      │
│  │ • Message Collector  │         │ • Response Formatter │      │
│  └──────────┬───────────┘         └──────────┬───────────┘      │
│             │                                 │                  │
│             │ HTTP POST                       │ HTTP POST        │
│             ▼                                 ▼                  │
│  ┌──────────────────────────────────────────────────────┐       │
│  │              QA Generator (Python)                   │       │
│  │              Port: 8000                              │       │
│  │                                                      │       │
│  │  ┌────────────────┐  ┌────────────────────────┐    │       │
│  │  │ Q&A Generation │  │  Similarity Search     │    │       │
│  │  │ (AWS Bedrock)  │  │  (FAISS)               │    │       │
│  │  └────────────────┘  └────────────────────────┘    │       │
│  │                                                      │       │
│  │  ┌────────────────┐  ┌────────────────────────┐    │       │
│  │  │ Embedding      │  │  Vector Store          │    │       │
│  │  │ (Transformers) │  │  Management            │    │       │
│  │  └────────────────┘  └────────────────────────┘    │       │
│  └──────────────────────┬───────────────────────────────┘       │
└─────────────────────────┼───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Data Layer                                │
│                                                                   │
│  ┌──────────────────────┐         ┌──────────────────────┐      │
│  │    PostgreSQL        │         │    FAISS Index       │      │
│  │    Port: 5432        │         │    (File System)     │      │
│  │                      │         │                      │      │
│  │ • qa_entries         │         │ • 768-dim vectors    │      │
│  │ • slack_threads      │         │ • Metadata JSON      │      │
│  │ • feedbacks          │         │ • IndexFlatL2        │      │
│  └──────────────────────┘         └──────────────────────┘      │
└─────────────────────────────────────────────────────────────────┘
```

## 컴포넌트 상세 설계

### 1. Slack Collector

**책임**:
- Slack Events API를 통한 메시지 수신
- 스레드 완료 감지 (5분 타이머)
- 메시지 정규화 및 저장
- 중복 수집 방지

**주요 클래스**:
```typescript
class ThreadCompletionDetector {
  // 5분 타이머로 스레드 완료 감지
  onMessageReceived(event: SlackMessageEvent): void
  processCompletedThread(channelId: string, threadTs: string): Promise<void>
}

class SlackApiService {
  // Slack API 호출 및 재시도 로직
  fetchThreadMessages(channelId: string, threadTs: string): Promise<Message[]>
  retryWithBackoff<T>(fn: () => Promise<T>, maxRetries: number): Promise<T>
}

class ThreadService {
  // 스레드 저장 및 중복 확인
  saveThread(thread: SlackThread): Promise<void>
  isThreadProcessed(threadTs: string): Promise<boolean>
}
```

**데이터 플로우**:
```
Slack Event → Event Handler → Thread Detector → 
5분 대기 → Fetch Messages → Save to DB → 
Trigger QA Generation
```

**요구사항**: 1.1, 1.2, 1.3, 1.4, 1.5

---

### 2. QA Generator

**책임**:
- 슬랙 대화 분석 및 Q&A 추출
- AWS Bedrock을 사용한 자연어 정제
- 벡터 임베딩 생성
- FAISS 인덱스 관리

**주요 모듈**:
```python
class BedrockService:
    # AWS Bedrock Claude 호출
    def generate_qa(self, messages: List[dict]) -> dict:
        # 프롬프트 생성 및 LLM 호출
        pass

class EmbeddingService:
    # Sentence Transformers 임베딩
    def generate_embedding(self, text: str) -> np.ndarray:
        # 768차원 벡터 생성
        pass

class VectorStoreService:
    # FAISS 인덱스 관리
    def add_vector(self, qa_id: str, vector: np.ndarray, metadata: dict):
        pass
    
    def search_similar(self, query_vector: np.ndarray, top_k: int) -> List[dict]:
        pass

class QAService:
    # Q&A 생성 오케스트레이션
    def process_thread(self, thread_id: str) -> List[QAEntry]:
        pass
```

**데이터 플로우**:
```
Thread Messages → Bedrock Analysis → Q&A Extraction → 
Embedding Generation → FAISS Index Update → 
Save to PostgreSQL
```

**요구사항**: 2.1, 2.2, 2.3, 2.4, 2.5, 3.5

---

### 3. Chatbot

**책임**:
- 슬랙 명령어 처리 (멘션, /ask)
- 유사 질문 검색
- 자동 응답 결정
- 피드백 수집

**주요 서비스**:
```typescript
class QuestionProcessor {
  // 질문 전처리 및 정규화
  normalizeQuestion(text: string): string
  extractKeywords(text: string): string[]
}

class QAService {
  // QA Generator와 통신
  searchSimilarQA(question: string, topK: number): Promise<QAMatch[]>
  shouldAutoRespond(matches: QAMatch[], threshold: number): boolean
}

class ResponseFormatter {
  // 슬랙 응답 포맷팅
  formatSingleAnswer(match: QAMatch): SlackBlock[]
  formatMultipleOptions(matches: QAMatch[]): SlackBlock[]
  formatEscalation(): SlackBlock[]
}
```

**데이터 플로우**:
```
Slack Command → Question Processing → 
QA Generator Query → Similarity Search → 
Auto-respond Decision → Format Response → 
Send to Slack
```

**요구사항**: 4.1, 4.2, 4.3, 4.4, 4.5, 5.1, 5.2, 5.3, 5.4, 5.5

---

### 4. PostgreSQL Database

**책임**:
- Q&A 메타데이터 저장
- 슬랙 스레드 저장
- 피드백 및 통계 관리

**테이블 관계**:
```
qa_entries (1) ──< (N) feedbacks
    │
    │ (참조)
    ▼
slack_threads
```

**트리거**:
- `update_qa_stats_on_feedback`: 피드백 제출 시 통계 자동 업데이트
- `update_updated_at`: Q&A 수정 시 updated_at 자동 갱신

**요구사항**: 3.1, 6.2

---

### 5. FAISS Vector Store

**책임**:
- 벡터 임베딩 저장
- 고속 유사도 검색 (ANN)
- 인덱스 영속화

**인덱스 타입**:
- **IndexFlatL2**: 정확한 검색 (< 10,000 벡터)
- **IndexIVFFlat**: 근사 검색 (> 10,000 벡터)

**검색 알고리즘**:
```python
# L2 거리 기반 검색
distances, indices = index.search(query_vector, k=3)

# 유사도 점수 변환 (0~1)
similarity_scores = 1 - (distances / 2)
```

**요구사항**: 3.5, 4.1

## 데이터 플로우

### 전체 워크플로우

```
1. 메시지 수집
   Slack Channel → Slack Collector → PostgreSQL (slack_threads)

2. Q&A 생성
   PostgreSQL → QA Generator → AWS Bedrock → 
   PostgreSQL (qa_entries) + FAISS Index

3. 자동 응답
   User Question → Chatbot → QA Generator (similarity search) → 
   FAISS Search → PostgreSQL (qa_entries) → 
   Response Formatting → Slack

4. 피드백 수집
   User Feedback → Chatbot → PostgreSQL (feedbacks) → 
   Trigger (update qa_entries stats)
```

### 메시지 수집 플로우 (상세)

```
1. Slack Event 수신
   POST /api/slack/events
   ↓
2. 서명 검증
   verifySlackSignature()
   ↓
3. 이벤트 타입 확인
   if (event.type === 'message')
   ↓
4. 스레드 타이머 설정/갱신
   ThreadCompletionDetector.onMessageReceived()
   ↓
5. 5분 대기
   setTimeout(5 * 60 * 1000)
   ↓
6. 스레드 메시지 수집
   SlackApiService.fetchThreadMessages()
   ↓
7. 데이터베이스 저장
   ThreadService.saveThread()
   ↓
8. Q&A 생성 트리거
   POST http://qa-generator:8000/api/qa/generate
```

### Q&A 생성 플로우 (상세)

```
1. 스레드 조회
   SELECT * FROM slack_threads WHERE id = ?
   ↓
2. 메시지 분석
   BedrockService.analyzeThread()
   ↓
3. AWS Bedrock 호출
   Claude 3.5 Sonnet API
   ↓
4. Q&A 추출 및 정제
   parse_bedrock_response()
   ↓
5. 벡터 임베딩 생성
   EmbeddingService.generate_embedding()
   ↓
6. FAISS 인덱스 업데이트
   VectorStoreService.add_vector()
   ↓
7. PostgreSQL 저장
   INSERT INTO qa_entries
   ↓
8. 스레드 처리 완료 표시
   UPDATE slack_threads SET is_processed = true
```

### 챗봇 응답 플로우 (상세)

```
1. 슬랙 명령어 수신
   @bot mention 또는 /ask command
   ↓
2. 질문 전처리
   QuestionProcessor.normalizeQuestion()
   ↓
3. 유사 Q&A 검색
   POST http://qa-generator:8000/api/chatbot/query
   ↓
4. 벡터 임베딩 생성
   EmbeddingService.generate_embedding()
   ↓
5. FAISS 검색
   VectorStoreService.search_similar(top_k=3)
   ↓
6. 메타데이터 조회
   SELECT * FROM qa_entries WHERE id IN (...)
   ↓
7. 자동 응답 결정
   QAService.shouldAutoRespond()
   ├─ 유사도 >= 0.8 → 자동 응답
   ├─ 0.6 <= 유사도 < 0.8 → 다중 옵션 제시
   └─ 유사도 < 0.6 → 운영팀 에스컬레이션
   ↓
8. 응답 포맷팅
   ResponseFormatter.format()
   ↓
9. 슬랙 전송
   Slack API: chat.postMessage
   ↓
10. 통계 업데이트
    UPDATE qa_entries SET view_count = view_count + 1
```

## 기술 스택 상세

### Backend Services

| 서비스 | 언어/프레임워크 | 주요 라이브러리 |
|--------|-----------------|----------------|
| Slack Collector | Node.js 20 / TypeScript 5.3 | @slack/bolt 3.17, Express 4.18, pg 8.11 |
| QA Generator | Python 3.10 | FastAPI 0.109, boto3 1.34, sentence-transformers 2.2 |
| Chatbot | Node.js 20 / TypeScript 5.3 | @slack/bolt 3.17, Express 4.18, axios 1.6 |

### AI/ML Stack

| 컴포넌트 | 기술 | 용도 |
|---------|------|------|
| Q&A 생성 | AWS Bedrock (Claude 3.5 Sonnet) | 대화 분석 및 Q&A 추출 |
| 임베딩 | Sentence Transformers (all-MiniLM-L6-v2) | 768차원 벡터 생성 |
| 벡터 검색 | FAISS (IndexFlatL2) | 코사인 유사도 기반 검색 |

### Data Storage

| 저장소 | 기술 | 용도 |
|--------|------|------|
| 메타데이터 | PostgreSQL 15 | Q&A, 스레드, 피드백 저장 |
| 벡터 인덱스 | FAISS (파일) | 임베딩 벡터 저장 및 검색 |

### Infrastructure

- **컨테이너화**: Docker 24.0
- **오케스트레이션**: Docker Compose 2.0
- **네트워킹**: Bridge Network
- **볼륨**: Named Volumes (postgres_data, faiss_data)

## 설계 결정 사항

### 1. 마이크로서비스 아키텍처 선택

**이유**:
- 각 서비스를 독립적으로 개발, 배포, 확장 가능
- 언어별 최적 도구 사용 (Node.js for Slack, Python for ML)
- 장애 격리 (한 서비스 장애가 전체 시스템에 영향 없음)

**트레이드오프**:
- 서비스 간 통신 오버헤드
- 분산 시스템 복잡도 증가

### 2. FAISS vs Pinecone

**FAISS 선택 이유**:
- 로컬 파일 시스템 저장 (외부 의존성 없음)
- 무료 (Pinecone은 유료)
- 빠른 검색 속도 (메모리 기반)
- 충분한 성능 (< 100,000 벡터)

**트레이드오프**:
- 수평 확장 어려움
- 수동 인덱스 관리 필요

### 3. AWS Bedrock vs OpenAI

**AWS Bedrock 선택 이유**:
- 엔터프라이즈 보안 및 컴플라이언스
- AWS 생태계 통합
- 데이터 프라이버시 (AWS 리전 내 처리)

**트레이드오프**:
- OpenAI보다 높은 비용
- 제한된 모델 선택

### 4. 동기 vs 비동기 Q&A 생성

**동기 처리 선택**:
- 간단한 구현
- 즉시 피드백
- 메시지 큐 불필요

**향후 개선**:
- 대량 스레드 처리 시 비동기 큐 도입 (Bull/Redis)

### 5. 스레드 완료 감지 (5분 타이머)

**이유**:
- 슬랙은 스레드 완료 이벤트를 제공하지 않음
- 5분은 대부분의 문의 응답 시간을 커버
- 타이머 기반 접근이 간단하고 신뢰성 있음

**트레이드오프**:
- 빠른 응답도 5분 대기
- 메모리에 타이머 상태 유지 (재시작 시 손실)

## 확장성 고려사항

### 수평 확장

**현재 제약**:
- FAISS 인덱스는 단일 인스턴스에서만 작동
- ThreadCompletionDetector 상태는 메모리에 저장

**확장 방안**:
1. **QA Generator 확장**:
   - FAISS를 Pinecone으로 마이그레이션
   - 또는 FAISS 인덱스를 공유 스토리지에 저장

2. **Slack Collector 확장**:
   - Redis를 사용한 분산 타이머 관리
   - 메시지 큐 도입 (RabbitMQ, Kafka)

3. **Chatbot 확장**:
   - 상태 비저장 설계 (이미 구현됨)
   - 로드 밸런서 추가

### 수직 확장

**리소스 요구사항**:
- **Slack Collector**: 512MB RAM, 0.5 CPU
- **QA Generator**: 2GB RAM, 1 CPU (임베딩 모델 로딩)
- **Chatbot**: 512MB RAM, 0.5 CPU
- **PostgreSQL**: 1GB RAM, 1 CPU

## 보안 아키텍처

### 인증 및 인가

```
Slack Request → Signature Verification → 
Timestamp Check → Request Processing
```

**구현**:
```typescript
function verifySlackSignature(req: Request): boolean {
  const timestamp = req.headers['x-slack-request-timestamp'];
  const signature = req.headers['x-slack-signature'];
  
  // 리플레이 공격 방지 (5분 이내 요청만 허용)
  if (Math.abs(Date.now() / 1000 - Number(timestamp)) > 300) {
    return false;
  }
  
  // HMAC-SHA256 서명 검증
  const hmac = crypto.createHmac('sha256', SLACK_SIGNING_SECRET);
  hmac.update(`v0:${timestamp}:${req.rawBody}`);
  const expectedSignature = `v0=${hmac.digest('hex')}`;
  
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSignature)
  );
}
```

### 데이터 보호

**민감 정보 마스킹**:
```typescript
// 이메일: user@example.com → u***@e***.com
// 전화번호: 010-1234-5678 → 010-****-****
// 주민번호: 123456-1234567 → ******-*******

function maskSensitiveData(text: string): string {
  return text
    .replace(/([a-zA-Z0-9._%+-]+)@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g, 
      (match, user, domain) => `${user[0]}***@${domain[0]}***.${domain.split('.').pop()}`)
    .replace(/\d{3}-\d{4}-\d{4}/g, '***-****-****')
    .replace(/\d{6}-\d{7}/g, '******-*******');
}
```

**로그 필터링**:
```typescript
// 토큰 자동 제외
logger.info('Slack API call', {
  channel: channelId,
  // token은 로그에서 제외됨
});
```

## 성능 특성

### 응답 시간

| 작업 | 목표 | 실제 |
|------|------|------|
| 챗봇 응답 | < 3초 | ~1-2초 |
| Q&A 생성 | < 30초 | ~10-20초 |
| 벡터 검색 | < 100ms | ~50ms |

### 처리량

- **메시지 수집**: ~100 메시지/분
- **Q&A 생성**: ~10 스레드/분
- **챗봇 쿼리**: ~50 쿼리/분

### 저장 용량

- **PostgreSQL**: ~1MB per 1,000 Q&A entries
- **FAISS Index**: ~3MB per 1,000 vectors (768-dim)

## 모니터링 지표

### 핵심 메트릭

1. **가용성**:
   - 서비스 업타임 (목표: 99.9%)
   - 헬스 체크 성공률

2. **성능**:
   - 평균 응답 시간
   - P95, P99 응답 시간
   - 처리량 (requests/sec)

3. **품질**:
   - 자동 응답 비율
   - 평균 유사도 점수
   - 긍정 피드백 비율

4. **에러**:
   - 에러율 (목표: < 1%)
   - Slack API 실패율
   - AWS Bedrock 실패율

### 알림 규칙

```yaml
alerts:
  - name: HighErrorRate
    condition: error_rate > 5%
    action: slack_notification
    
  - name: SlowResponse
    condition: p95_response_time > 5s
    action: slack_notification
    
  - name: ServiceDown
    condition: health_check_failed
    action: slack_notification + pagerduty
```

## 향후 개선 사항

### 단기 (1-3개월)

1. **캐싱 레이어 추가**:
   - Redis를 사용한 응답 캐싱
   - 자주 조회되는 Q&A 캐싱

2. **비동기 처리**:
   - Bull Queue를 사용한 Q&A 생성
   - 백그라운드 작업 처리

3. **관리자 대시보드**:
   - Q&A 관리 UI
   - 통계 대시보드
   - 피드백 모니터링

### 중기 (3-6개월)

1. **멀티 테넌시**:
   - 여러 워크스페이스 지원
   - 테넌트별 데이터 격리

2. **고급 검색**:
   - 하이브리드 검색 (키워드 + 벡터)
   - 필터링 (카테고리, 날짜 등)

3. **A/B 테스팅**:
   - 다양한 임계값 테스트
   - 응답 포맷 최적화

### 장기 (6-12개월)

1. **멀티모달 지원**:
   - 이미지, 파일 첨부 처리
   - 스크린샷 분석

2. **다국어 지원**:
   - 자동 언어 감지
   - 다국어 임베딩 모델

3. **능동적 학습**:
   - 피드백 기반 모델 재학습
   - 자동 Q&A 품질 개선

## 참고 자료

- [Slack API 문서](https://api.slack.com/)
- [AWS Bedrock 문서](https://docs.aws.amazon.com/bedrock/)
- [FAISS 문서](https://github.com/facebookresearch/faiss)
- [Sentence Transformers 문서](https://www.sbert.net/)
