# Slack Q&A Chatbot 빠른 시작 가이드

이 가이드는 Slack Q&A Chatbot을 5분 안에 실행하는 방법을 설명합니다.

## 1단계: 사전 요구사항 확인

다음 항목이 설치되어 있는지 확인하세요:

- ✅ Docker 20.10 이상
- ✅ Docker Compose 2.0 이상
- ✅ Git

확인 방법:
```bash
docker --version
docker-compose --version
git --version
```

## 2단계: 저장소 클론

```bash
git clone <repository-url>
cd slack-qa-chatbot
```

## 3단계: Slack 앱 생성

### 3.1 앱 생성
1. https://api.slack.com/apps 접속
2. "Create New App" → "From scratch" 선택
3. 앱 이름 입력 (예: "Q&A Chatbot")
4. 워크스페이스 선택

### 3.2 권한 설정
**OAuth & Permissions** 메뉴에서 다음 스코프 추가:
- `app_mentions:read`
- `channels:history`
- `channels:read`
- `chat:write`
- `commands`

### 3.3 이벤트 구독
**Event Subscriptions** 메뉴에서:
1. "Enable Events" 활성화
2. Request URL: `https://your-domain.com/api/slack/events`
3. Bot events 추가:
   - `app_mention`
   - `message.channels`

### 3.4 슬래시 커맨드
**Slash Commands** 메뉴에서:
- Command: `/ask`
- Request URL: `https://your-domain.com/api/chatbot/query`

### 3.5 앱 설치
**Install App** 메뉴에서 워크스페이스에 설치


## 4단계: AWS 설정

### 4.1 IAM 사용자 생성
1. AWS Console → IAM → Users → "Create user"
2. 사용자 이름 입력 (예: "slack-qa-bot")
3. "Attach policies directly" 선택
4. 다음 정책 추가:
   - `AmazonBedrockFullAccess`

### 4.2 액세스 키 생성
1. 생성된 사용자 선택
2. "Security credentials" 탭
3. "Create access key" 클릭
4. "Application running outside AWS" 선택
5. Access Key ID와 Secret Access Key 복사

## 5단계: 환경 변수 설정

```bash
cp .env.example .env
nano .env  # 또는 원하는 에디터 사용
```

다음 값을 입력하세요:

```bash
# Slack (3단계에서 획득)
SLACK_BOT_TOKEN=xoxb-your-bot-token
SLACK_SIGNING_SECRET=your-signing-secret

# AWS (4단계에서 획득)
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-access-key-id
AWS_SECRET_ACCESS_KEY=your-secret-access-key

# Database (강력한 비밀번호로 변경)
POSTGRES_PASSWORD=your-strong-password
DATABASE_URL=postgresql://postgres:your-strong-password@postgres:5432/slack_qa_bot
```

## 6단계: 채널 설정

`services/slack-collector/channels.json` 파일 수정:

```json
{
  "channels": [
    {
      "id": "C01234567",
      "name": "customer-support",
      "enabled": true
    }
  ]
}
```

채널 ID 확인 방법:
1. 슬랙에서 채널 이름 우클릭
2. "링크 복사" 선택
3. URL에서 마지막 부분이 채널 ID (예: C01234567)

## 7단계: 서비스 실행

```bash
docker-compose up -d
```

## 8단계: 상태 확인

```bash
# 서비스 상태
docker-compose ps

# 로그 확인
docker-compose logs -f

# 헬스 체크
curl http://localhost:3000/health
curl http://localhost:8000/health
curl http://localhost:3001/health
```

모든 서비스가 `{"status": "ok"}`를 반환하면 성공!

## 9단계: 봇을 채널에 추가

1. 슬랙에서 수집 대상 채널 열기
2. 채널 상단의 "통합" 클릭
3. "앱 추가" 클릭
4. 생성한 봇 검색 및 추가

## 10단계: 테스트

### 메시지 수집 테스트
1. 슬랙 채널에서 새 스레드 생성:
   ```
   질문: 로톡 서비스 가입은 어떻게 하나요?
   답변: 로톡 홈페이지에서 회원가입 버튼을 클릭하세요.
   ```
2. 5분 대기 (스레드 완료 감지)
3. 로그 확인:
   ```bash
   docker-compose logs slack-collector | grep "Thread completed"
   ```

### 챗봇 테스트
1. 슬랙에서 봇 멘션:
   ```
   @Q&A Chatbot 로톡 가입 방법을 알려주세요
   ```
2. 봇이 자동으로 답변하는지 확인

## 문제 해결

### 서비스가 시작되지 않음
```bash
docker-compose logs [service-name]
docker-compose restart [service-name]
```

### Slack 이벤트가 수신되지 않음
- Request URL이 올바른지 확인
- ngrok 사용 (로컬 개발):
  ```bash
  ngrok http 3000
  ```
- Slack 앱 설정에서 ngrok URL 업데이트

### AWS Bedrock 오류
- IAM 권한 확인
- 리전 확인 (Bedrock은 특정 리전에서만 사용 가능)
- 액세스 키 확인

## 다음 단계

- [전체 문서](../README.md) 읽기
- [아키텍처 문서](./ARCHITECTURE.md) 확인
- [배포 가이드](./DEPLOYMENT_GUIDE.md) 참조
- [E2E 테스트](../tests/e2e/README.md) 실행

## 지원

문제가 발생하면:
1. [README 문제 해결 섹션](../README.md#문제-해결) 확인
2. GitHub Issues 생성
3. 로그 파일 첨부
