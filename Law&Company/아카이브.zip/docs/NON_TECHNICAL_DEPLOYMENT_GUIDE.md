# 비개발자를 위한 Slack Q&A 챗봇 배포 가이드

이 가이드는 기술적 배경이 없는 분들도 Slack Q&A 챗봇을 배포할 수 있도록 단계별로 설명합니다.

## 목차
1. [필요한 것들](#필요한-것들)
2. [1단계: 서버 준비하기](#1단계-서버-준비하기)
3. [2단계: Slack 앱 만들기](#2단계-slack-앱-만들기)
4. [3단계: AWS 계정 설정하기](#3단계-aws-계정-설정하기)
5. [4단계: 챗봇 설치하기](#4단계-챗봇-설치하기)
6. [5단계: 테스트하기](#5단계-테스트하기)
7. [문제가 생겼을 때](#문제가-생겼을-때)

---

## 필요한 것들

배포를 시작하기 전에 다음 항목들이 필요합니다:

### 1. 계정 및 권한
- ✅ **Slack 워크스페이스 관리자 권한**
  - 슬랙에서 앱을 설치할 수 있는 권한이 필요합니다
  - 확인 방법: 슬랙 → 설정 → 관리 메뉴가 보이면 OK

- ✅ **AWS 계정**
  - AI 기능을 사용하기 위해 필요합니다
  - 없으면 [aws.amazon.com](https://aws.amazon.com)에서 무료로 만들 수 있습니다
  - 신용카드 등록이 필요합니다 (사용한 만큼만 과금)

### 2. 서버 (다음 중 하나 선택)

**옵션 A: 클라우드 서버 (권장)**
- AWS, Google Cloud, 또는 Naver Cloud 등
- 월 비용: 약 3만원~10만원
- 장점: 안정적이고 관리가 쉬움

**옵션 B: 회사 내부 서버**
- IT 팀에 서버 요청
- 필요 사양: 4GB RAM, 2 CPU, 20GB 저장공간
- 외부에서 접근 가능한 공인 IP 필요

### 3. 도움을 줄 수 있는 사람
- 개발자 또는 IT 담당자 1명
- 처음 설치할 때만 도움이 필요합니다

---

## 1단계: 서버 준비하기

### 옵션 A: AWS 서버 사용 (가장 쉬움)

#### 1.1 AWS 계정 만들기
1. [aws.amazon.com](https://aws.amazon.com) 접속
2. "AWS 계정 생성" 클릭
3. 이메일, 비밀번호, 회사 정보 입력
4. 신용카드 등록 (무료 체험 가능)

#### 1.2 서버 만들기 (EC2)
1. AWS 콘솔 로그인
2. 상단 검색창에 "EC2" 입력
3. "인스턴스 시작" 버튼 클릭
4. 다음 설정 선택:
   - **이름**: slack-qa-chatbot
   - **운영체제**: Ubuntu Server 22.04 LTS
   - **인스턴스 유형**: t3.medium (4GB RAM)
   - **키 페어**: 새로 만들기 → 다운로드 (중요! 잃어버리면 안됨)
   - **스토리지**: 20GB
5. "인스턴스 시작" 클릭

#### 1.3 서버 접속 정보 확인
- 인스턴스 목록에서 방금 만든 서버 클릭
- **퍼블릭 IPv4 주소** 복사 (예: 3.35.123.45)
- 이 주소를 메모장에 저장해두세요

**💰 예상 비용**: 월 약 5만원 (24시간 운영 기준)

---

### 옵션 B: 회사 서버 사용

IT 담당자에게 다음 정보를 전달하세요:

```
서버 요청 사항:
- 운영체제: Ubuntu 22.04 또는 CentOS 8
- CPU: 2코어 이상
- RAM: 4GB 이상
- 저장공간: 20GB 이상
- 네트워크: 외부에서 접근 가능한 공인 IP
- 필요한 포트: 80 (HTTP), 443 (HTTPS)
- Docker 설치 필요
```

---

## 2단계: Slack 앱 만들기

### 2.1 Slack 앱 생성

1. **Slack API 페이지 접속**
   - [api.slack.com/apps](https://api.slack.com/apps) 접속
   - Slack 계정으로 로그인

2. **새 앱 만들기**
   - "Create New App" 버튼 클릭
   - "From scratch" 선택
   - 앱 이름 입력: `Q&A 챗봇` (원하는 이름 가능)
   - 워크스페이스 선택
   - "Create App" 클릭

### 2.2 권한 설정

1. **왼쪽 메뉴에서 "OAuth & Permissions" 클릭**

2. **"Scopes" 섹션으로 스크롤**

3. **"Bot Token Scopes"에 다음 권한 추가**:
   - `app_mentions:read` - 봇이 멘션될 때 알림
   - `channels:history` - 채널 메시지 읽기
   - `channels:read` - 채널 정보 보기
   - `chat:write` - 메시지 보내기
   - `commands` - 명령어 사용

   각 권한을 추가하려면:
   - "Add an OAuth Scope" 버튼 클릭
   - 위 권한 이름 입력 또는 선택

### 2.3 이벤트 구독 설정

1. **왼쪽 메뉴에서 "Event Subscriptions" 클릭**

2. **"Enable Events" 토글을 켜기**

3. **Request URL 입력** (나중에 다시 설정할 예정)
   - 일단 비워두고 다음 단계로

4. **"Subscribe to bot events" 섹션에서 이벤트 추가**:
   - "Add Bot User Event" 클릭
   - `app_mention` 추가
   - `message.channels` 추가

5. **"Save Changes" 클릭**

### 2.4 슬래시 커맨드 추가

1. **왼쪽 메뉴에서 "Slash Commands" 클릭**

2. **"Create New Command" 클릭**

3. **다음 정보 입력**:
   - Command: `/ask`
   - Request URL: (나중에 설정)
   - Short Description: `챗봇에게 질문하기`
   - Usage Hint: `[질문 내용]`

4. **"Save" 클릭**

### 2.5 앱 설치

1. **왼쪽 메뉴에서 "Install App" 클릭**

2. **"Install to Workspace" 버튼 클릭**

3. **권한 승인**

4. **중요! 토큰 복사하기**
   - "Bot User OAuth Token" 복사 (xoxb-로 시작)
   - 메모장에 저장:
     ```
     SLACK_BOT_TOKEN=xoxb-1234567890-1234567890-abcdefghijklmnop
     ```

### 2.6 Signing Secret 복사

1. **왼쪽 메뉴에서 "Basic Information" 클릭**

2. **"App Credentials" 섹션 찾기**

3. **"Signing Secret" 옆의 "Show" 클릭**

4. **복사해서 메모장에 저장**:
   ```
   SLACK_SIGNING_SECRET=abcdef1234567890abcdef1234567890
   ```

---

## 3단계: AWS 계정 설정하기

챗봇이 AI 기능을 사용하려면 AWS Bedrock 서비스가 필요합니다.

### 3.1 IAM 사용자 만들기

1. **AWS 콘솔에서 "IAM" 검색**

2. **왼쪽 메뉴에서 "사용자" 클릭**

3. **"사용자 추가" 버튼 클릭**

4. **사용자 정보 입력**:
   - 사용자 이름: `slack-qa-bot`
   - "다음" 클릭

5. **권한 설정**:
   - "직접 정책 연결" 선택
   - 검색창에 "Bedrock" 입력
   - `AmazonBedrockFullAccess` 체크
   - "다음" 클릭

6. **"사용자 생성" 클릭**

### 3.2 액세스 키 만들기

1. **방금 만든 사용자 클릭**

2. **"보안 자격 증명" 탭 클릭**

3. **"액세스 키 만들기" 버튼 클릭**

4. **"AWS 외부에서 실행되는 애플리케이션" 선택**

5. **"다음" → "액세스 키 만들기" 클릭**

6. **중요! 키 정보 복사**:
   - 액세스 키 ID 복사
   - 비밀 액세스 키 복사 (한 번만 보여줍니다!)
   - 메모장에 저장:
     ```
     AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
     AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
     ```

### 3.3 Bedrock 모델 액세스 요청

1. **AWS 콘솔에서 "Bedrock" 검색**

2. **왼쪽 메뉴에서 "Model access" 클릭**

3. **"Modify model access" 버튼 클릭**

4. **"Anthropic - Claude 3.5 Sonnet" 체크**

5. **"Request model access" 클릭**

6. **승인 대기 (보통 즉시 승인됨)**

---

## 4단계: 챗봇 설치하기

이 단계는 개발자나 IT 담당자의 도움이 필요할 수 있습니다.

### 4.1 서버에 접속하기

**Windows 사용자**:
1. PuTTY 프로그램 다운로드 및 설치
2. Host Name에 서버 IP 입력
3. 다운로드한 키 파일 선택
4. "Open" 클릭

**Mac 사용자**:
1. 터미널 열기
2. 다음 명령어 입력:
   ```bash
   ssh -i "다운로드한키파일.pem" ubuntu@서버IP주소
   ```

### 4.2 필요한 프로그램 설치

서버에 접속한 후 다음 명령어를 순서대로 입력하세요:

```bash
# 1. 시스템 업데이트
sudo apt update
sudo apt upgrade -y

# 2. Docker 설치
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# 3. Docker Compose 설치
sudo apt install docker-compose -y

# 4. Git 설치
sudo apt install git -y
```

### 4.3 챗봇 코드 다운로드

```bash
# 프로젝트 폴더로 이동
cd ~

# 코드 다운로드 (실제 저장소 주소로 변경 필요)
git clone https://github.com/your-company/slack-qa-chatbot.git

# 프로젝트 폴더로 이동
cd slack-qa-chatbot
```

### 4.4 설정 파일 만들기

```bash
# 설정 파일 복사
cp .env.example .env

# 설정 파일 편집
nano .env
```

다음 내용을 입력하세요 (2단계와 3단계에서 복사한 값 사용):

```bash
# Slack 설정
SLACK_BOT_TOKEN=xoxb-여기에-복사한-토큰-붙여넣기
SLACK_SIGNING_SECRET=여기에-복사한-시크릿-붙여넣기

# AWS 설정
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=여기에-복사한-액세스키-붙여넣기
AWS_SECRET_ACCESS_KEY=여기에-복사한-시크릿키-붙여넣기
BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20241022-v2:0

# 데이터베이스 설정 (비밀번호를 강력하게 변경하세요!)
POSTGRES_PASSWORD=여기에-강력한-비밀번호-입력
DATABASE_URL=postgresql://postgres:위에서입력한비밀번호@postgres:5432/slack_qa_bot

# 기타 설정
CONFIDENCE_THRESHOLD=0.8
```

저장하기:
- `Ctrl + X` 누르기
- `Y` 입력
- `Enter` 누르기

### 4.5 수집할 채널 설정

```bash
# 채널 설정 파일 편집
nano services/slack-collector/channels.json
```

다음 내용 입력:

```json
{
  "channels": [
    {
      "id": "C01234567",
      "name": "customer-support",
      "enabled": true
    }
  ]
}
```

**채널 ID 찾는 방법**:
1. 슬랙에서 채널 이름 우클릭
2. "링크 복사" 선택
3. URL 끝부분이 채널 ID (예: C01234567)

저장하기: `Ctrl + X` → `Y` → `Enter`

### 4.6 챗봇 시작하기

```bash
# 챗봇 시작
sudo docker-compose up -d

# 상태 확인
sudo docker-compose ps
```

모든 서비스가 "Up" 상태면 성공!

### 4.7 Slack 앱 설정 완료하기

이제 서버 주소를 알았으니 Slack 앱 설정을 완료합니다.

1. **[api.slack.com/apps](https://api.slack.com/apps) 접속**

2. **만든 앱 선택**

3. **"Event Subscriptions" 메뉴**:
   - Request URL에 입력: `http://서버IP주소:3000/api/slack/events`
   - 초록색 체크 표시가 나오면 성공
   - "Save Changes" 클릭

4. **"Slash Commands" 메뉴**:
   - `/ask` 명령어 클릭
   - Request URL에 입력: `http://서버IP주소:3001/api/chatbot/query`
   - "Save" 클릭

---

## 5단계: 테스트하기

### 5.1 봇을 채널에 추가

1. **슬랙에서 테스트할 채널 열기**

2. **채널 이름 클릭 → "통합" 탭**

3. **"앱 추가" 클릭**

4. **만든 챗봇 검색 및 추가**

### 5.2 메시지 수집 테스트

1. **채널에서 새 스레드 작성**:
   ```
   질문: 로톡 서비스 가입은 어떻게 하나요?
   ```

2. **스레드에 답변 작성**:
   ```
   답변: 로톡 홈페이지에서 회원가입 버튼을 클릭하세요.
   ```

3. **5분 대기** (시스템이 스레드 완료를 감지)

4. **서버에서 로그 확인**:
   ```bash
   sudo docker-compose logs slack-collector | grep "Thread completed"
   ```

### 5.3 챗봇 응답 테스트

1. **채널에서 봇 멘션**:
   ```
   @Q&A 챗봇 로톡 가입 방법을 알려주세요
   ```

2. **또는 슬래시 커맨드 사용**:
   ```
   /ask 로톡 가입 방법을 알려주세요
   ```

3. **봇이 자동으로 답변하면 성공!** 🎉

---

## 문제가 생겼을 때

### 봇이 응답하지 않아요

**확인 사항**:
1. 서버가 실행 중인지 확인:
   ```bash
   sudo docker-compose ps
   ```

2. 로그 확인:
   ```bash
   sudo docker-compose logs chatbot
   ```

3. Slack 앱 설정의 Request URL이 올바른지 확인

### "Connection refused" 오류

**해결 방법**:
1. 서버 방화벽 확인 (IT 담당자에게 문의)
2. AWS 보안 그룹에서 포트 3000, 3001 열기:
   - EC2 → 보안 그룹 → 인바운드 규칙 편집
   - 포트 3000, 3001 추가

### Q&A가 생성되지 않아요

**확인 사항**:
1. AWS Bedrock 모델 액세스가 승인되었는지 확인
2. AWS 자격증명이 올바른지 확인
3. 로그 확인:
   ```bash
   sudo docker-compose logs qa-generator
   ```

### 서버 재시작하기

```bash
# 모든 서비스 중지
sudo docker-compose down

# 다시 시작
sudo docker-compose up -d
```

---

## 도움 받기

### 로그 파일 저장하기

문제가 생기면 로그를 저장해서 개발자에게 전달하세요:

```bash
# 모든 로그 저장
sudo docker-compose logs > logs.txt

# 특정 서비스 로그만 저장
sudo docker-compose logs chatbot > chatbot-logs.txt
```

### 연락처

- **기술 지원**: IT 담당자 또는 개발팀
- **Slack 관련**: Slack 워크스페이스 관리자
- **AWS 관련**: AWS 고객 지원

---

## 비용 안내

### 예상 월 비용

| 항목 | 비용 |
|------|------|
| AWS EC2 서버 (t3.medium) | 약 50,000원 |
| AWS Bedrock (Claude 사용) | 사용량에 따라 10,000~50,000원 |
| 데이터 전송 | 약 5,000원 |
| **총 예상 비용** | **약 65,000~105,000원/월** |

**비용 절감 팁**:
- 야간/주말에는 서버 중지 (수동 관리 필요)
- 더 작은 서버 사용 (t3.small) - 성능 저하 가능
- AWS 프리티어 활용 (첫 12개월)

---

## 다음 단계

챗봇이 정상 작동하면:

1. **더 많은 채널 추가**
   - `channels.json` 파일에 채널 추가

2. **성능 모니터링**
   - 주기적으로 로그 확인
   - 응답 속도 체크

3. **Q&A 품질 관리**
   - 부정확한 답변 수정
   - 새로운 Q&A 추가

4. **백업 설정**
   - 주기적으로 데이터베이스 백업
   - 설정 파일 백업

---

**축하합니다! 🎉**

Slack Q&A 챗봇 배포를 완료했습니다. 이제 팀원들의 반복적인 질문에 자동으로 답변할 수 있습니다.

궁금한 점이 있으면 IT 담당자나 개발팀에 문의하세요.
