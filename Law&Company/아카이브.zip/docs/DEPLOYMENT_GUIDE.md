# Slack Q&A Chatbot 배포 가이드

이 문서는 Slack Q&A Chatbot 시스템을 프로덕션 환경에 배포하는 방법을 설명합니다.

## 목차

- [사전 요구사항](#사전-요구사항)
- [환경 설정](#환경-설정)
- [Docker Compose 배포](#docker-compose-배포)
- [클라우드 배포](#클라우드-배포)
- [모니터링 및 유지보수](#모니터링-및-유지보수)
- [백업 및 복구](#백업-및-복구)

## 사전 요구사항

### 인프라

- **서버**: 최소 4GB RAM, 2 CPU 코어
- **스토리지**: 최소 20GB (로그 및 데이터용)
- **네트워크**: 공인 IP 또는 도메인 (Slack 이벤트 수신용)
- **Docker**: 20.10 이상
- **Docker Compose**: 2.0 이상

### 외부 서비스

1. **Slack 워크스페이스**
   - 관리자 권한
   - Slack 앱 생성 권한

2. **AWS 계정**
   - Bedrock 서비스 액세스 권한
   - IAM 사용자 또는 역할

3. **도메인 (선택사항)**
   - HTTPS 인증서 (Let's Encrypt 권장)

## 환경 설정

### 1. 환경 변수 파일 생성

```bash
cp .env.example .env
```

### 2. 필수 환경 변수 설정

```bash
# Slack Configuration
SLACK_BOT_TOKEN=xoxb-your-actual-bot-token
SLACK_SIGNING_SECRET=your-actual-signing-secret

# AWS Bedrock Configuration
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-aws-access-key
AWS_SECRET_ACCESS_KEY=your-aws-secret-key
BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20241022-v2:0

# Database Configuration
POSTGRES_DB=slack_qa_bot
POSTGRES_USER=postgres
POSTGRES_PASSWORD=CHANGE_THIS_STRONG_PASSWORD
DATABASE_URL=postgresql://postgres:CHANGE_THIS_STRONG_PASSWORD@postgres:5432/slack_qa_bot

# QA Generator Configuration
EMBEDDING_MODEL=sentence-transformers/all-MiniLM-L6-v2
FAISS_INDEX_PATH=/app/data/faiss_index.bin
FAISS_METADATA_PATH=/app/data/faiss_metadata.json
CONFIDENCE_THRESHOLD=0.8

# Service Ports
SLACK_COLLECTOR_PORT=3000
QA_GENERATOR_PORT=8000
CHATBOT_PORT=3001
```

### 3. 보안 강화

**강력한 비밀번호 생성**:
```bash
# PostgreSQL 비밀번호 생성
openssl rand -base64 32
```

**파일 권한 설정**:
```bash
chmod 600 .env
```

### 4. 수집 대상 채널 설정

`services/slack-collector/channels.json`:
```json
{
  "channels": [
    {
      "id": "C01234567",
      "name": "customer-support",
      "enabled": true
    },
    {
      "id": "C98765432",
      "name": "technical-support",
      "enabled": true
    }
  ]
}
```

## Docker Compose 배포

### 1. 이미지 빌드

```bash
docker-compose build
```

### 2. 서비스 시작

```bash
# 백그라운드 모드로 시작
docker-compose up -d

# 로그 확인
docker-compose logs -f
```

### 3. 헬스 체크

```bash
# 모든 서비스 상태 확인
docker-compose ps

# 개별 서비스 헬스 체크
curl http://localhost:3000/health  # Slack Collector
curl http://localhost:8000/health  # QA Generator
curl http://localhost:3001/health  # Chatbot
```

### 4. 데이터베이스 초기화 확인

```bash
docker-compose exec postgres psql -U postgres -d slack_qa_bot -c "\dt"
```

예상 출력:
```
             List of relations
 Schema |     Name      | Type  |  Owner   
--------+---------------+-------+----------
 public | feedbacks     | table | postgres
 public | qa_entries    | table | postgres
 public | slack_threads | table | postgres
```

## 클라우드 배포

### AWS ECS 배포

#### 1. ECR에 이미지 푸시

```bash
# ECR 로그인
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <account-id>.dkr.ecr.us-east-1.amazonaws.com

# 이미지 태그 및 푸시
docker tag slack-collector:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/slack-collector:latest
docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/slack-collector:latest

docker tag qa-generator:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/qa-generator:latest
docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/qa-generator:latest

docker tag chatbot:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/chatbot:latest
docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/chatbot:latest
```

#### 2. RDS PostgreSQL 생성

```bash
aws rds create-db-instance \
  --db-instance-identifier slack-qa-bot-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --engine-version 15.4 \
  --master-username postgres \
  --master-user-password <strong-password> \
  --allocated-storage 20 \
  --vpc-security-group-ids sg-xxxxx \
  --db-subnet-group-name my-subnet-group
```

#### 3. ECS 태스크 정의 생성

`ecs-task-definition.json`:
```json
{
  "family": "slack-qa-chatbot",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "1024",
  "memory": "2048",
  "containerDefinitions": [
    {
      "name": "slack-collector",
      "image": "<account-id>.dkr.ecr.us-east-1.amazonaws.com/slack-collector:latest",
      "portMappings": [
        {
          "containerPort": 3000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {"name": "NODE_ENV", "value": "production"}
      ],
      "secrets": [
        {"name": "SLACK_BOT_TOKEN", "valueFrom": "arn:aws:secretsmanager:..."},
        {"name": "DATABASE_URL", "valueFrom": "arn:aws:secretsmanager:..."}
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/slack-qa-chatbot",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "slack-collector"
        }
      }
    }
  ]
}
```

#### 4. ECS 서비스 생성

```bash
aws ecs create-service \
  --cluster my-cluster \
  --service-name slack-qa-chatbot \
  --task-definition slack-qa-chatbot \
  --desired-count 1 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxxxx],securityGroups=[sg-xxxxx],assignPublicIp=ENABLED}"
```

#### 5. Application Load Balancer 설정

```bash
# 타겟 그룹 생성
aws elbv2 create-target-group \
  --name slack-collector-tg \
  --protocol HTTP \
  --port 3000 \
  --vpc-id vpc-xxxxx \
  --target-type ip

# 리스너 규칙 추가
aws elbv2 create-rule \
  --listener-arn arn:aws:elasticloadbalancing:... \
  --conditions Field=path-pattern,Values='/api/slack/events' \
  --priority 1 \
  --actions Type=forward,TargetGroupArn=arn:aws:elasticloadbalancing:...
```

### Google Cloud Run 배포

#### 1. 이미지 빌드 및 푸시

```bash
# Cloud Build 사용
gcloud builds submit --tag gcr.io/<project-id>/slack-collector services/slack-collector
gcloud builds submit --tag gcr.io/<project-id>/qa-generator services/qa-generator
gcloud builds submit --tag gcr.io/<project-id>/chatbot services/chatbot
```

#### 2. Cloud Run 서비스 배포

```bash
# Slack Collector
gcloud run deploy slack-collector \
  --image gcr.io/<project-id>/slack-collector \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars SLACK_BOT_TOKEN=<token>,DATABASE_URL=<url>

# QA Generator
gcloud run deploy qa-generator \
  --image gcr.io/<project-id>/qa-generator \
  --platform managed \
  --region us-central1 \
  --no-allow-unauthenticated

# Chatbot
gcloud run deploy chatbot \
  --image gcr.io/<project-id>/chatbot \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated
```

#### 3. Cloud SQL PostgreSQL 연결

```bash
gcloud sql instances create slack-qa-bot-db \
  --database-version=POSTGRES_15 \
  --tier=db-f1-micro \
  --region=us-central1

# Cloud Run에서 Cloud SQL 연결
gcloud run services update slack-collector \
  --add-cloudsql-instances <project-id>:us-central1:slack-qa-bot-db
```

## HTTPS 설정

### Let's Encrypt (Certbot)

```bash
# Certbot 설치
sudo apt-get install certbot

# 인증서 발급
sudo certbot certonly --standalone -d your-domain.com

# Nginx 설정
sudo nano /etc/nginx/sites-available/slack-qa-chatbot
```

`/etc/nginx/sites-available/slack-qa-chatbot`:
```nginx
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl;
    server_name your-domain.com;

    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    location /api/slack/events {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /api/chatbot {
        proxy_pass http://localhost:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

```bash
# Nginx 활성화
sudo ln -s /etc/nginx/sites-available/slack-qa-chatbot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## 모니터링 및 유지보수

### 로그 관리

#### 로그 로테이션

`/etc/logrotate.d/docker-compose`:
```
/var/lib/docker/containers/*/*.log {
    rotate 7
    daily
    compress
    size=10M
    missingok
    delaycompress
    copytruncate
}
```

#### 중앙 집중식 로깅 (ELK Stack)

```yaml
# docker-compose.yml에 추가
services:
  elasticsearch:
    image: docker.elastic.co/elasticsearch/elasticsearch:8.11.0
    environment:
      - discovery.type=single-node
    volumes:
      - elasticsearch_data:/usr/share/elasticsearch/data

  logstash:
    image: docker.elastic.co/logstash/logstash:8.11.0
    volumes:
      - ./logstash.conf:/usr/share/logstash/pipeline/logstash.conf

  kibana:
    image: docker.elastic.co/kibana/kibana:8.11.0
    ports:
      - "5601:5601"
```

### 메트릭 수집 (Prometheus)

```yaml
# docker-compose.yml에 추가
services:
  prometheus:
    image: prom/prometheus:latest
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    ports:
      - "9090:9090"

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3002:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
```

### 헬스 체크 스크립트

`scripts/health-check.sh`:
```bash
#!/bin/bash

SERVICES=("slack-collector:3000" "qa-generator:8000" "chatbot:3001")

for service in "${SERVICES[@]}"; do
    IFS=':' read -r name port <<< "$service"
    
    if curl -f http://localhost:$port/health > /dev/null 2>&1; then
        echo "✓ $name is healthy"
    else
        echo "✗ $name is unhealthy"
        # 슬랙 알림 전송
        curl -X POST https://hooks.slack.com/services/YOUR/WEBHOOK/URL \
          -H 'Content-Type: application/json' \
          -d "{\"text\":\"⚠️ $name service is down!\"}"
    fi
done
```

### Cron 작업 설정

```bash
# crontab -e
# 5분마다 헬스 체크
*/5 * * * * /path/to/scripts/health-check.sh

# 매일 자정 데이터베이스 백업
0 0 * * * /path/to/scripts/backup-db.sh

# 매주 일요일 로그 정리
0 0 * * 0 docker system prune -f
```

## 백업 및 복구

### 데이터베이스 백업

#### 자동 백업 스크립트

`scripts/backup-db.sh`:
```bash
#!/bin/bash

BACKUP_DIR="/backups/postgres"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/slack_qa_bot_$TIMESTAMP.sql"

mkdir -p $BACKUP_DIR

docker-compose exec -T postgres pg_dump -U postgres slack_qa_bot > $BACKUP_FILE

# 압축
gzip $BACKUP_FILE

# 7일 이상 된 백업 삭제
find $BACKUP_DIR -name "*.sql.gz" -mtime +7 -delete

echo "Backup completed: $BACKUP_FILE.gz"
```

#### 데이터베이스 복구

```bash
# 백업 파일 압축 해제
gunzip backup.sql.gz

# 복구
docker-compose exec -T postgres psql -U postgres slack_qa_bot < backup.sql
```

### FAISS 인덱스 백업

```bash
# 백업
docker cp qa-generator:/app/data/faiss_index.bin ./backups/
docker cp qa-generator:/app/data/faiss_metadata.json ./backups/

# 복구
docker cp ./backups/faiss_index.bin qa-generator:/app/data/
docker cp ./backups/faiss_metadata.json qa-generator:/app/data/
docker-compose restart qa-generator
```

### 전체 시스템 백업

```bash
#!/bin/bash

BACKUP_DIR="/backups/full"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR/$TIMESTAMP

# 데이터베이스 백업
docker-compose exec -T postgres pg_dump -U postgres slack_qa_bot > $BACKUP_DIR/$TIMESTAMP/database.sql

# FAISS 인덱스 백업
docker cp qa-generator:/app/data $BACKUP_DIR/$TIMESTAMP/faiss_data

# 설정 파일 백업
cp .env $BACKUP_DIR/$TIMESTAMP/
cp services/slack-collector/channels.json $BACKUP_DIR/$TIMESTAMP/

# 압축
tar -czf $BACKUP_DIR/backup_$TIMESTAMP.tar.gz -C $BACKUP_DIR $TIMESTAMP

# 정리
rm -rf $BACKUP_DIR/$TIMESTAMP

echo "Full backup completed: $BACKUP_DIR/backup_$TIMESTAMP.tar.gz"
```

## 업데이트 및 롤백

### 서비스 업데이트

```bash
# 최신 코드 가져오기
git pull origin main

# 이미지 재빌드
docker-compose build

# 무중단 업데이트 (서비스별)
docker-compose up -d --no-deps --build slack-collector
docker-compose up -d --no-deps --build qa-generator
docker-compose up -d --no-deps --build chatbot
```

### 롤백

```bash
# 이전 버전으로 체크아웃
git checkout <previous-commit>

# 이미지 재빌드 및 재시작
docker-compose build
docker-compose up -d
```

## 성능 튜닝

### PostgreSQL 최적화

`postgresql.conf`:
```
shared_buffers = 256MB
effective_cache_size = 1GB
maintenance_work_mem = 64MB
checkpoint_completion_target = 0.9
wal_buffers = 16MB
default_statistics_target = 100
random_page_cost = 1.1
effective_io_concurrency = 200
work_mem = 4MB
min_wal_size = 1GB
max_wal_size = 4GB
```

### Docker 리소스 제한

`docker-compose.yml`:
```yaml
services:
  slack-collector:
    deploy:
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
        reservations:
          cpus: '0.25'
          memory: 256M

  qa-generator:
    deploy:
      resources:
        limits:
          cpus: '1.0'
          memory: 2G
        reservations:
          cpus: '0.5'
          memory: 1G
```

## 보안 체크리스트

- [ ] 강력한 데이터베이스 비밀번호 사용
- [ ] HTTPS 활성화
- [ ] 방화벽 설정 (필요한 포트만 개방)
- [ ] 환경 변수 파일 권한 설정 (600)
- [ ] AWS IAM 최소 권한 원칙 적용
- [ ] Slack 서명 검증 활성화
- [ ] 정기적인 보안 업데이트
- [ ] 로그에서 민감 정보 제외
- [ ] 백업 암호화
- [ ] 접근 로그 모니터링

## 문제 해결

배포 중 문제가 발생하면 [README.md의 문제 해결 섹션](../README.md#문제-해결)을 참조하세요.

## 지원

추가 지원이 필요하면:
- GitHub Issues 생성
- 로그 파일 첨부
- 환경 정보 제공 (OS, Docker 버전 등)
