# 구현 계획: Slack Q&A 챗봇

## 개요

슬랙 메시지를 수집하여 Q&A를 자동 생성하고, 유사 질문에 대해 자동 응답하는 챗봇 시스템을 구현합니다. Node.js(TypeScript), Python, PostgreSQL, Pinecone을 사용하여 마이크로서비스 아키텍처로 구성됩니다.

## 구현 태스크

- [x] 1. 프로젝트 구조 및 공통 설정
  - 루트 디렉토리에 docker-compose.yml 생성
  - services 디렉토리 생성 (slack-collector, qa-generator, chatbot)
  - 공통 환경 변수 파일 (.env.example) 생성
  - PostgreSQL 초기화 스크립트 작성 (테이블 스키마)
  - _요구사항: 1.2, 3.1_

- [ ] 2. 데이터베이스 스키마 구현
  - [x] 2.1 PostgreSQL 마이그레이션 스크립트 작성
    - qa_entries 테이블 생성 (id, question, answer, category, status, 통계 필드 등)
    - slack_threads 테이블 생성 (thread_ts, channel_id, messages, is_processed 등)
    - feedbacks 테이블 생성 (qa_entry_id, user_id, feedback_type 등)
    - 필요한 인덱스 생성
    - _요구사항: 3.1, 1.3, 6.2_

  - [ ]* 2.2 데이터베이스 연결 테스트 작성
    - 연결 풀 설정 테스트
    - 기본 CRUD 작업 테스트
    - _요구사항: 3.1_

- [ ] 3. Slack_Collector 서비스 구현
  - [x] 3.1 Node.js/TypeScript 프로젝트 초기화
    - package.json 설정 (Slack Bolt SDK, pg 등)
    - TypeScript 설정 (tsconfig.json)
    - 기본 Express 서버 구조 생성
    - _요구사항: 1.2_

  - [x] 3.2 Slack Events API 연동
    - Slack Bolt 앱 초기화
    - 이벤트 구독 엔드포인트 구현 (/api/slack/events)
    - 메시지 이벤트 핸들러 구현
    - Slack 서명 검증 구현
    - _요구사항: 1.1, 1.2_

  - [x] 3.3 스레드 완료 감지 로직 구현
    - ThreadCompletionDetector 클래스 구현
    - 5분 타이머 기반 스레드 완료 감지
    - 중복 수집 방지 로직 (thread_ts 기반)
    - _요구사항: 1.1, 1.5_

  - [x] 3.4 메시지 수집 및 저장
    - Slack API를 통한 스레드 메시지 조회
    - slack_threads 테이블에 저장 (작성자, 시간, 본문 포함)
    - 설정 파일 기반 채널 목록 관리
    - _요구사항: 1.1, 1.2, 1.3_

  - [x] 3.5 에러 처리 및 재시도 로직
    - Slack API 호출 실패 시 재시도 (최대 3회)
    - 에러 로깅 구현
    - _요구사항: 1.4_

  - [ ]* 3.6 Slack_Collector 통합 테스트
    - 메시지 수집 플로우 테스트
    - 중복 방지 테스트
    - 재시도 로직 테스트
    - _요구사항: 1.1, 1.4, 1.5_

- [x] 4. Checkpoint - 슬랙 수집기 검증
  - Slack_Collector 서비스가 정상 동작하는지 확인
  - 테스트 슬랙 채널에서 메시지 수집 테스트
  - 질문이 있으면 사용자에게 문의

- [ ] 5. QA_Generator 서비스 구현
  - [x] 5.1 Python 프로젝트 초기화
    - requirements.txt 작성 (openai, psycopg2, sentence-transformers, pinecone-client 등)
    - 프로젝트 구조 생성 (main.py, models/, services/)
    - 환경 변수 로딩 설정
    - _요구사항: 2.1_

  - [x] 5.2 데이터베이스 연결 및 모델 구현
    - PostgreSQL 연결 풀 설정
    - QAEntry, SlackThread 모델 클래스 구현
    - CRUD 함수 구현
    - _요구사항: 2.3, 3.1_

  - [x] 5.3 OpenAI API 연동 및 Q&A 생성 로직
    - generate_qa_from_thread 함수 구현
    - 메시지 전처리 및 질문 식별
    - LLM 프롬프트 작성 및 호출
    - 답변 추출 및 정제
    - 미완료 스레드 처리 (답변 없는 경우)
    - _요구사항: 2.1, 2.2, 2.4, 2.5_

  - [x] 5.4 벡터 임베딩 생성 및 Pinecone 연동
    - Sentence Transformers 모델 로딩
    - generate_embedding 함수 구현
    - Pinecone 인덱스 초기화
    - 벡터 저장 로직 구현
    - _요구사항: 3.5_

  - [x] 5.5 Q&A 저장 및 업데이트
    - qa_entries 테이블에 Q&A 저장
    - Pinecone에 벡터 저장
    - 기존 Q&A 업데이트 로직 (운영팀 답변 반영)
    - _요구사항: 2.3, 6.4_

  - [ ]* 5.6 QA_Generator 단위 테스트
    - Q&A 생성 로직 테스트
    - 임베딩 생성 테스트
    - 미완료 스레드 처리 테스트
    - _요구사항: 2.1, 2.4_

- [ ] 6. Checkpoint - Q&A 생성기 검증
  - QA_Generator가 슬랙 스레드로부터 Q&A를 생성하는지 확인
  - 벡터 임베딩이 Pinecone에 저장되는지 확인
  - 질문이 있으면 사용자에게 문의

- [ ] 7. Similarity_Engine 구현
  - [x] 7.1 유사도 검색 함수 구현
    - find_similar_questions 함수 구현
    - 쿼리 임베딩 생성
    - Pinecone 벡터 검색 (top_k=3)
    - 임계값 필터링 (threshold=0.7)
    - _요구사항: 4.1, 4.5_

  - [x] 7.2 자동 응답 결정 로직 구현
    - should_auto_respond 함수 구현
    - 유사도 점수 확인 (confidence_threshold=0.8)
    - 피드백 비율 기반 품질 확인
    - 상위 매치 간 점수 차이 확인
    - _요구사항: 4.2, 4.3_

  - [ ]* 7.3 유사도 검색 단위 테스트
    - 유사도 계산 정확도 테스트
    - 임계값 필터링 테스트
    - 자동 응답 결정 로직 테스트
    - _요구사항: 4.1, 4.2, 4.3_

- [ ] 8. Chatbot 서비스 구현
  - [x] 8.1 Node.js/TypeScript 프로젝트 초기화
    - package.json 설정 (Slack Bolt SDK, axios 등)
    - TypeScript 설정
    - Express 서버 구조 생성
    - _요구사항: 5.1_

  - [x] 8.2 Slack 명령어 처리
    - 멘션 이벤트 핸들러 구현
    - 슬래시 커맨드 (/ask) 핸들러 구현
    - 질문 텍스트 추출 및 정규화
    - _요구사항: 5.1, 5.2_

  - [x] 8.3 질문 처리 및 응답 생성
    - /api/chatbot/query 엔드포인트 구현
    - Similarity_Engine 호출 (Python 서비스 HTTP 요청)
    - 응답 포맷팅 (유사도 점수, 원본 참조 포함)
    - 슬랙 스레드로 응답 전송
    - _요구사항: 4.1, 4.2, 4.4, 5.1_

  - [ ] 8.4 다중 후보 제시 로직
    - 상위 3개 Q&A 항목 포맷팅
    - 슬랙 블록 UI로 선택 가능한 옵션 제공
    - _요구사항: 4.5_

  - [ ] 8.5 에스컬레이션 로직
    - 자동 응답 불가 시 운영팀에게 문의 전달
    - _요구사항: 4.3, 5.4_

  - [ ] 8.6 응답 시간 최적화
    - 타임아웃 설정 (3초)
    - 캐싱 레이어 추가 (Redis - 선택사항)
    - _요구사항: 5.5_

  - [ ]* 8.7 Chatbot 통합 테스트
    - 질문-응답 플로우 테스트
    - 에스컬레이션 테스트
    - _요구사항: 5.1, 5.4_

- [x] 9. Checkpoint - 챗봇 기본 기능 검증
  - Chatbot이 질문을 받아 유사 Q&A를 검색하는지 확인
  - 질문이 있으면 사용자에게 문의

- [ ] 10. Q&A 관리 API 구현
  - [x] 10.1 Q&A 검색 API
    - 키워드 기반 검색 구현
    - 카테고리 필터링
    - 상태 필터링 (active/inactive/pending)
    - _요구사항: 3.2_

  - [x] 10.2 Q&A 수정 API
    - PUT /api/qa/:id 엔드포인트 구현
    - 질문, 답변, 카테고리, 상태 수정
    - 수정 시 updated_at 갱신
    - 벡터 임베딩 재생성 및 업데이트
    - _요구사항: 3.3_

  - [x] 10.3 Q&A 비활성화 기능
    - 상태를 'inactive'로 변경
    - Pinecone 메타데이터 업데이트
    - 챗봇 응답 대상에서 제외
    - _요구사항: 3.4_

  - [ ]* 10.4 Q&A 관리 API 테스트
    - 검색 기능 테스트
    - 수정 기능 테스트
    - 비활성화 테스트
    - _요구사항: 3.2, 3.3, 3.4_

- [ ] 11. 서비스 통합 및 Docker 설정
  - [x] 11.1 Docker 이미지 작성
    - Slack_Collector Dockerfile 작성
    - QA_Generator Dockerfile 작성
    - Chatbot Dockerfile 작성
    - _요구사항: 1.1, 2.1, 5.1_

  - [x] 11.2 서비스 간 통신 구현
    - Slack_Collector → QA_Generator 호출 (HTTP/메시지 큐)
    - Chatbot → Similarity_Engine 호출 (HTTP)
    - 에러 처리 및 재시도
    - _요구사항: 1.1, 2.1, 4.1_

  - [x] 11.3 환경 변수 및 설정 관리
    - .env.example 파일 완성
    - 각 서비스별 설정 파일 작성
    - 신뢰도 임계값 설정 (CONFIDENCE_THRESHOLD=0.8)
    - _요구사항: 1.2, 4.2_

  - [ ]* 11.4 Docker Compose 통합 테스트
    - 전체 시스템 기동 테스트
    - 서비스 간 통신 테스트
    - 데이터베이스 연결 테스트
    - _요구사항: 1.1, 2.1, 5.1_

- [x] 12. 보안 및 에러 처리 강화
  - [x] 12.1 Slack 서명 검증 구현
    - 모든 Slack 이벤트에 대한 서명 검증
    - 타임스탬프 검증 (리플레이 공격 방지)
    - _요구사항: 1.1, 5.1_

  - [x] 12.2 에러 로깅 및 모니터링
    - 구조화된 JSON 로깅 구현
    - 로그 레벨 설정 (DEBUG, INFO, WARN, ERROR)
    - 에러율 임계값 초과 시 슬랙 알림
    - _요구사항: 1.4_

  - [x] 12.3 민감 정보 보호
    - 로그에서 토큰 제외
    - 개인정보 자동 마스킹 (선택사항)
    - _요구사항: 1.3_

- [x] 13. 최종 통합 테스트 및 문서화
  - [x] 13.1 End-to-End 시나리오 테스트
    - 슬랙 메시지 수집 → Q&A 생성 → 챗봇 응답 전체 플로우 테스트
    - _요구사항: 1.1, 2.1, 4.1, 5.1_

  - [x] 13.2 README 및 배포 가이드 작성
    - 프로젝트 개요 및 아키텍처 설명
    - 환경 변수 설정 가이드
    - Docker Compose 실행 방법
    - Slack 앱 설정 가이드
    - _요구사항: 1.2, 5.1_

- [x] 14. 최종 Checkpoint
  - 모든 테스트가 통과하는지 확인
  - 슬랙에서 실제 시나리오 테스트
  - 질문이 있으면 사용자에게 문의

## 참고사항

- `*` 표시된 태스크는 선택 사항이며, 빠른 MVP 구현을 위해 건너뛸 수 있습니다
- 각 태스크는 요구사항 추적을 위해 관련 요구사항 번호를 명시합니다
- Checkpoint 태스크에서 중간 검증을 수행하여 점진적으로 품질을 확보합니다
- 서비스 간 통신은 HTTP REST API를 기본으로 하며, 필요시 메시지 큐(Bull/Redis)로 전환 가능합니다
