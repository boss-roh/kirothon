# 기술 설계 문서

## 개요

본 문서는 슬랙 Q&A 챗봇 시스템의 기술 설계를 정의한다. 시스템은 슬랙 메시지 수집, Q&A 자동 생성, 유사도 기반 검색, 자동 응답의 4가지 핵심 기능으로 구성된다.

## 시스템 아키텍처

### High-Level 아키텍처

```
┌─────────────────┐
│   Slack API     │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────┐
│                    Application Layer                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │ Slack_       │  │ QA_          │  │ Chatbot      │  │
│  │ Collector    │─▶│ Generator    │  │              │  │
│  └──────────────┘  └──────┬───────┘  └──────┬───────┘  │
│                            │                  │          │
│                            ▼                  ▼          │
│                    ┌──────────────────────────┐          │
│                    │  Similarity_Engine       │          │
│                    └──────────┬───────────────┘          │
└───────────────────────────────┼──────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────┐
│                    Data Layer                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │ QA_Store     │  │ Vector DB    │  │ Config Store │  │
│  │ (PostgreSQL) │  │ (Pinecone)   │  │ (JSON)       │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────┘
```

### 컴포넌트 설명

#### 1. Slack_Collector (슬랙 수집기)
- 역할: 슬랙 채널의 메시지 및 스레드 수집
- 기술 스택: Node.js, Slack Bolt SDK
- 주요 기능:
  - 슬랙 이벤트 구독 (Events API)
  - 스레드 완료 감지
  - 메시지 데이터 정규화

#### 2. QA_Generator (Q&A 생성기)
- 역할: 수집된 대화를 Q&A 형식으로 변환
- 기술 스택: Python, AWS Bedrock (Claude 3.5 Sonnet)
- 주요 기능:
  - 대화 분석 및 질문-답변 추출
  - 자연어 정제
  - 벡터 임베딩 생성

#### 3. Similarity_Engine (유사도 검색기)
- 역할: 질문 간 의미적 유사도 계산
- 기술 스택: Python, Sentence Transformers
- 주요 기능:
  - 텍스트 임베딩
  - 코사인 유사도 계산
  - 벡터 검색

#### 4. Chatbot (챗봇)
- 역할: 사용자 문의 처리 및 응답
- 기술 스택: Node.js, Slack Bolt SDK
- 주요 기능:
  - 슬랙 명령어 처리
  - 응답 생성 및 전송
  - 피드백 수집

#### 5. QA_Store (Q&A 저장소)
- 역할: Q&A 데이터 영구 저장
- 기술 스택: PostgreSQL
- 주요 기능:
  - CRUD 연산
  - 메타데이터 관리
  - 통계 집계

#### 6. Vector Store (벡터 저장소)
- 역할: 임베딩 벡터 저장 및 검색
- 기술 스택: FAISS (Facebook AI Similarity Search)
- 주요 기능:
  - 로컬 벡터 인덱스 저장 (파일 시스템)
  - 고속 근사 최근접 이웃 검색 (ANN)
  - 인덱스 영속화 및 로딩

## 데이터 모델

### QA_Entry (Q&A 항목)

```sql
CREATE TABLE qa_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    category VARCHAR(100),
    source_thread_id VARCHAR(255) NOT NULL,
    source_channel_id VARCHAR(255) NOT NULL,
    status VARCHAR(20) DEFAULT 'active', -- active, inactive, pending
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(255),
    
    -- 통계 필드
    view_count INTEGER DEFAULT 0,
    positive_feedback_count INTEGER DEFAULT 0,
    negative_feedback_count INTEGER DEFAULT 0,
    
    -- 인덱스
    CONSTRAINT status_check CHECK (status IN ('active', 'inactive', 'pending'))
);

CREATE INDEX idx_qa_status ON qa_entries(status);
CREATE INDEX idx_qa_category ON qa_entries(category);
CREATE INDEX idx_qa_created_at ON qa_entries(created_at);
```

### Slack_Thread (슬랙 스레드)

```sql
CREATE TABLE slack_threads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    thread_ts VARCHAR(255) NOT NULL UNIQUE,
    channel_id VARCHAR(255) NOT NULL,
    messages JSONB NOT NULL,
    is_processed BOOLEAN DEFAULT FALSE,
    collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP,
    
    -- 인덱스
    CONSTRAINT unique_thread UNIQUE (thread_ts, channel_id)
);

CREATE INDEX idx_thread_processed ON slack_threads(is_processed);
CREATE INDEX idx_thread_channel ON slack_threads(channel_id);
```

### Feedback (피드백)

```sql
CREATE TABLE feedbacks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    qa_entry_id UUID REFERENCES qa_entries(id) ON DELETE CASCADE,
    user_id VARCHAR(255) NOT NULL,
    feedback_type VARCHAR(20) NOT NULL, -- positive, negative
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT feedback_type_check CHECK (feedback_type IN ('positive', 'negative'))
);

CREATE INDEX idx_feedback_qa_entry ON feedbacks(qa_entry_id);
CREATE INDEX idx_feedback_type ON feedbacks(feedback_type);
```

### Vector_Embedding (벡터 임베딩)

벡터 임베딩은 FAISS 인덱스 파일과 메타데이터 JSON 파일로 저장됩니다:

```python
# FAISS 인덱스 구조
# 파일: data/faiss_index.bin
# - 768차원 벡터 저장 (sentence-transformers/all-MiniLM-L6-v2)
# - IndexFlatL2 또는 IndexIVFFlat 사용

# 메타데이터 구조
# 파일: data/faiss_metadata.json
{
    "vectors": [
        {
            "id": "qa_entry_uuid",
            "qa_entry_id": "uuid",
            "question": "원본 질문 텍스트",
            "category": "카테고리",
            "status": "active"
        }
    ]
}
```

## API 설계

### 1. Slack_Collector API

#### POST /api/slack/events
슬랙 이벤트 수신

```typescript
interface SlackEvent {
    type: string;
    event: {
        type: 'message' | 'app_mention';
        channel: string;
        user: string;
        text: string;
        ts: string;
        thread_ts?: string;
    };
}

Response: { ok: boolean }
```

#### POST /api/collector/process-thread
스레드 수동 처리

```typescript
Request: {
    channel_id: string;
    thread_ts: string;
}

Response: {
    success: boolean;
    thread_id: string;
    message_count: number;
}
```

### 2. QA_Generator API

#### POST /api/qa/generate
Q&A 생성

```typescript
Request: {
    thread_id: string;
}

Response: {
    success: boolean;
    qa_entries: Array<{
        id: string;
        question: string;
        answer: string;
        confidence: number;
    }>;
}
```

#### PUT /api/qa/:id
Q&A 수정

```typescript
Request: {
    question?: string;
    answer?: string;
    category?: string;
    status?: 'active' | 'inactive' | 'pending';
}

Response: {
    success: boolean;
    qa_entry: QAEntry;
}
```

### 3. Chatbot API

#### POST /api/chatbot/query
질문 처리

```typescript
Request: {
    question: string;
    user_id: string;
    channel_id: string;
}

Response: {
    success: boolean;
    matches: Array<{
        qa_entry_id: string;
        question: string;
        answer: string;
        similarity_score: number;
    }>;
    auto_respond: boolean;
}
```

#### POST /api/chatbot/feedback
피드백 제출

```typescript
Request: {
    qa_entry_id: string;
    user_id: string;
    feedback_type: 'positive' | 'negative';
    comment?: string;
}

Response: {
    success: boolean;
    feedback_id: string;
}
```

### 4. Analytics API

#### GET /api/analytics/stats
통계 조회

```typescript
Request: {
    start_date: string;
    end_date: string;
}

Response: {
    total_queries: number;
    auto_response_rate: number;
    average_similarity_score: number;
    positive_feedback_rate: number;
    top_categories: Array<{
        category: string;
        count: number;
    }>;
}
```

## 주요 알고리즘

### 1. Q&A 생성 알고리즘

```python
def generate_qa_from_thread(thread_messages):
    """
    슬랙 스레드로부터 Q&A 항목 생성
    """
    # 1. 메시지 전처리
    cleaned_messages = preprocess_messages(thread_messages)
    
    # 2. 질문 식별
    question = identify_question(cleaned_messages[0])
    
    # 3. 답변 추출 및 통합
    answer_candidates = extract_answers(cleaned_messages[1:])
    
    if not answer_candidates:
        return {"status": "pending", "reason": "no_answer"}
    
    # 4. AWS Bedrock (Claude)을 사용한 Q&A 정제
    prompt = f"""
    다음 슬랙 대화에서 질문과 답변을 추출하여 정리해주세요.
    
    질문: {question}
    답변 후보: {answer_candidates}
    
    출력 형식:
    - 질문: [정제된 질문]
    - 답변: [통합되고 정제된 답변]
    """
    
    refined_qa = call_bedrock_claude(prompt)
    
    # 5. 벡터 임베딩 생성
    embedding = generate_embedding(refined_qa['question'])
    
    # 6. 저장
    qa_entry = save_qa_entry(
        question=refined_qa['question'],
        answer=refined_qa['answer'],
        source_thread_id=thread_messages[0]['thread_ts'],
        embedding=embedding
    )
    
    return qa_entry
```

### 2. 유사도 검색 알고리즘

```python
def find_similar_questions(query, top_k=3, threshold=0.7):
    """
    유사한 질문 검색
    
    Args:
        query: 사용자 질문
        top_k: 반환할 최대 결과 수
        threshold: 최소 유사도 점수
    
    Returns:
        유사한 Q&A 항목 리스트
    """
    # 1. 쿼리 임베딩 생성
    query_embedding = generate_embedding(query)
    
    # 2. FAISS 인덱스에서 유사 벡터 검색
    distances, indices = faiss_index.search(
        query_embedding.reshape(1, -1),
        top_k
    )
    
    # 3. 메타데이터에서 활성 상태 필터링
    results = []
    for idx, distance in zip(indices[0], distances[0]):
        metadata = faiss_metadata[idx]
        if metadata['status'] == 'active':
            results.append({
                'id': metadata['qa_entry_id'],
                'score': 1 - (distance / 2),  # L2 거리를 유사도로 변환
                'metadata': metadata
            })
    
    # 3. 임계값 필터링
    filtered_results = [
        r for r in results 
        if r['score'] >= threshold
    ]
    
    # 4. 상세 정보 조회
    qa_entries = []
    for result in filtered_results:
        qa_entry = db.query(
            "SELECT * FROM qa_entries WHERE id = %s",
            (result['id'],)
        )
        qa_entry['similarity_score'] = result['score']
        qa_entries.append(qa_entry)
    
    return qa_entries
```

### 3. 자동 응답 결정 알고리즘

```python
def should_auto_respond(similarity_matches, confidence_threshold=0.8):
    """
    자동 응답 여부 결정
    
    Args:
        similarity_matches: 유사도 검색 결과
        confidence_threshold: 신뢰도 임계값
    
    Returns:
        (should_respond: bool, best_match: dict)
    """
    if not similarity_matches:
        return False, None
    
    best_match = similarity_matches[0]
    
    # 1. 유사도 점수 확인
    if best_match['similarity_score'] < confidence_threshold:
        return False, None
    
    # 2. Q&A 항목 품질 확인
    feedback_ratio = calculate_positive_feedback_ratio(best_match['id'])
    
    if feedback_ratio < 0.5 and best_match['view_count'] > 10:
        # 부정 피드백이 많은 경우 자동 응답 제외
        return False, None
    
    # 3. 상위 매치와의 점수 차이 확인
    if len(similarity_matches) > 1:
        score_gap = (
            best_match['similarity_score'] - 
            similarity_matches[1]['similarity_score']
        )
        
        if score_gap < 0.1:
            # 점수가 비슷한 경우 여러 옵션 제시
            return False, similarity_matches[:3]
    
    return True, best_match

def calculate_positive_feedback_ratio(qa_entry_id):
    """긍정 피드백 비율 계산"""
    stats = db.query("""
        SELECT 
            positive_feedback_count,
            negative_feedback_count
        FROM qa_entries
        WHERE id = %s
    """, (qa_entry_id,))
    
    total = stats['positive_feedback_count'] + stats['negative_feedback_count']
    
    if total == 0:
        return 1.0  # 피드백 없는 경우 중립
    
    return stats['positive_feedback_count'] / total
```

### 4. 스레드 완료 감지 알고리즘

```typescript
class ThreadCompletionDetector {
    private threadTimers: Map<string, NodeJS.Timeout> = new Map();
    private readonly COMPLETION_DELAY = 5 * 60 * 1000; // 5분
    
    onMessageReceived(event: SlackMessageEvent) {
        const threadKey = `${event.channel}_${event.thread_ts}`;
        
        // 기존 타이머 취소
        if (this.threadTimers.has(threadKey)) {
            clearTimeout(this.threadTimers.get(threadKey)!);
        }
        
        // 새 타이머 설정
        const timer = setTimeout(() => {
            this.processCompletedThread(event.channel, event.thread_ts);
            this.threadTimers.delete(threadKey);
        }, this.COMPLETION_DELAY);
        
        this.threadTimers.set(threadKey, timer);
    }
    
    async processCompletedThread(channelId: string, threadTs: string) {
        // 스레드 메시지 수집
        const messages = await this.slackClient.conversations.replies({
            channel: channelId,
            ts: threadTs
        });
        
        // Q&A 생성 트리거
        await this.qaGenerator.generate({
            channel_id: channelId,
            thread_ts: threadTs,
            messages: messages.messages
        });
    }
}
```

## 배포 아키텍처

### 컨테이너 구성

```yaml
# docker-compose.yml
version: '3.8'

services:
  slack-collector:
    build: ./services/slack-collector
    environment:
      - SLACK_BOT_TOKEN=${SLACK_BOT_TOKEN}
      - SLACK_SIGNING_SECRET=${SLACK_SIGNING_SECRET}
      - DATABASE_URL=${DATABASE_URL}
    ports:
      - "3000:3000"
    depends_on:
      - postgres
      
  qa-generator:
    build: ./services/qa-generator
    environment:
      - AWS_REGION=${AWS_REGION}
      - AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID}
      - AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY}
      - DATABASE_URL=${DATABASE_URL}
    volumes:
      - faiss_data:/app/data
    depends_on:
      - postgres
      
  chatbot:
    build: ./services/chatbot
    environment:
      - SLACK_BOT_TOKEN=${SLACK_BOT_TOKEN}
      - DATABASE_URL=${DATABASE_URL}
      - QA_GENERATOR_URL=http://qa-generator:8000
    ports:
      - "3001:3001"
    depends_on:
      - postgres
      - qa-generator
      
  postgres:
    image: postgres:15
    environment:
      - POSTGRES_DB=slack_qa_bot
      - POSTGRES_USER=${DB_USER}
      - POSTGRES_PASSWORD=${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
      
volumes:
  postgres_data:
  faiss_data:
```

### 환경 변수

```bash
# .env
SLACK_BOT_TOKEN=xoxb-your-bot-token
SLACK_SIGNING_SECRET=your-signing-secret
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your-aws-access-key
AWS_SECRET_ACCESS_KEY=your-aws-secret-key
DATABASE_URL=postgresql://user:password@postgres:5432/slack_qa_bot
CONFIDENCE_THRESHOLD=0.8
BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20241022-v2:0
```

## 보안 고려사항

1. API 인증
   - 슬랙 서명 검증
   - JWT 기반 내부 API 인증

2. 데이터 암호화
   - 전송 중: TLS 1.3
   - 저장 시: PostgreSQL 투명 데이터 암호화

3. 접근 제어
   - 슬랙 워크스페이스 기반 권한 관리
   - 운영자 역할 기반 접근 제어 (RBAC)

4. 민감 정보 처리
   - 개인정보 자동 마스킹
   - 로그에서 토큰 제외

## 성능 최적화

1. 캐싱 전략
   - Redis를 사용한 자주 조회되는 Q&A 캐싱
   - 벡터 검색 결과 캐싱 (TTL: 1시간)

2. 데이터베이스 최적화
   - 인덱스 최적화
   - 연결 풀링 (최대 20개 연결)

3. 비동기 처리
   - Q&A 생성: 메시지 큐 (Bull/Redis)
   - 벡터 임베딩: 배치 처리

4. 응답 시간 목표
   - 챗봇 응답: < 3초
   - Q&A 생성: < 30초 (비동기)

## 모니터링 및 로깅

1. 메트릭
   - 응답 시간
   - 자동 응답 비율
   - 에러율
   - 피드백 점수

2. 로깅
   - 구조화된 JSON 로깅
   - 로그 레벨: DEBUG, INFO, WARN, ERROR
   - 중앙 집중식 로그 수집 (ELK Stack)

3. 알림
   - 에러율 임계값 초과 시 슬랙 알림
   - 시스템 다운타임 알림
